export default function Rides() {
  return (
    <div className='p-6'>
      <h1 className='text-2xl font-bold mb-4'>Rides</h1>
      <p>Manage all ride details here.</p>
    </div>
  );
}